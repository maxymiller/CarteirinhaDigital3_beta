package com.senai.carteirinhadigital.app.session

import androidx.lifecycle.ViewModel
import com.senai.carteirinhadigital.core.auth.SessionTokenStore
import com.senai.carteirinhadigital.feature.auth.domain.model.UsuarioLogado
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionViewModel(
    private val sessionTokenStore: SessionTokenStore
): ViewModel() {
    private val _usuarioLogado = MutableStateFlow<UsuarioLogado?>(null)
    val usuarioLogado: StateFlow<UsuarioLogado?> = _usuarioLogado.asStateFlow()

    fun setUsuarioLogado(usuario: UsuarioLogado) {
        sessionTokenStore.salvar(usuario.token)
        _usuarioLogado.value=usuario
    }

    fun limparUsuarioLogado() {
        _usuarioLogado.value=null
    }
}