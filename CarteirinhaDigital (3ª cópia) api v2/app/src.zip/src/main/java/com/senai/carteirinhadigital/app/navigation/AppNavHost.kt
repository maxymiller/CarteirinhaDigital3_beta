package com.senai.carteirinhadigital.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.senai.carteirinhadigital.app.di.AppContainer
import com.senai.carteirinhadigital.app.navigation.aluno.alunoNavGraph
import com.senai.carteirinhadigital.app.navigation.auth.authNavGraph
import com.senai.carteirinhadigital.app.navigation.professor.professorNavGraph
import com.senai.carteirinhadigital.app.session.SessionViewModel
import com.senai.carteirinhadigital.app.session.SessionViewModelFactory
import com.senai.carteirinhadigital.feature.auth.domain.model.PerfilAcesso
import com.senai.carteirinhadigital.feature.desenvolvimentoDeSistemas.navigation.desenvolvimentoDeSistemasScreen
import com.senai.carteirinhadigital.feature.eletronica.navigation.eletronicaScreen
//import com.senai.carteirinhadigital.feature.home.navigation.homeScreen
//import com.senai.carteirinhadigital.feature.homeProfessor.navigation.homeProfessorScreen
//import com.senai.carteirinhadigital.feature.mecatronica.navigation.mecatronicaScreen
//import com.senai.carteirinhadigital.feature.unidadecurricular.navigation.unidadeScreen

import com.senai.carteirinhadigital.feature.auth.presentation.LoginScreen;
import com.senai.carteirinhadigital.feature.auth.presentation.LoginViewMode
import com.senai.carteirinhadigital.feature.auth.presentation.factory.LoginViewModelFactory

@Composable
fun AppNavHost(
    navController: NavHostController,
    darkTheme: Boolean,
    onDarkThemeChange: (Boolean) -> Unit,
    container: AppContainer
) {

    val sessionFactory = remember(container.sessionTokenStore) {
        SessionViewModelFactory(
            sessionTokenStore = container.sessionTokenStore
        )
    }

    val sessionViewModel: SessionViewModel = viewModel(
        factory = sessionFactory
    )

    fun graphFor(perfil: PerfilAcesso): String {
        return when (perfil) {
            PerfilAcesso.ALUNO -> GraphRoutes.ALUNO
            PerfilAcesso.PROFESSOR -> GraphRoutes.PROFESSOR
        }
    }

    fun replaceGraph(
        currentGraph: String,
        destinationGraph: String
    ) {

        navController.navigate(destinationGraph) {
            popUpTo(currentGraph) {
                inclusive = true
            }
            launchSingleTop = true
        }
    }

    NavHost(
        navController = navController,
        startDestination = GraphRoutes.AUTH
    ) {
        authNavGraph(
            loginRepository = container.loginRepository,
            onLoginSucesso = { usuario ->
                sessionViewModel.setUsuarioLogado(usuario)
                replaceGraph(
                    currentGraph = GraphRoutes.AUTH,
                    destinationGraph = graphFor(usuario.perfil)
                )
            }
        )

        alunoNavGraph(
            navController = navController,
            usuarioLogadoFlow = sessionViewModel.usuarioLogado,
            unidadeCurricularRepository = container.unidadeCurricularRepository,
            darkTheme = darkTheme,
            onDarkThemeChange = onDarkThemeChange,
            onLogout = {
                sessionViewModel.limparUsuarioLogado()
                replaceGraph(
                    currentGraph = GraphRoutes.ALUNO,
                    destinationGraph = GraphRoutes.AUTH
                )
            },
            onSessaoAusente = {
                replaceGraph(
                    currentGraph = GraphRoutes.ALUNO,
                    destinationGraph = GraphRoutes.AUTH
                )
            },
            onPerfilInvalido = { perfil ->
                replaceGraph(
                    currentGraph = GraphRoutes.ALUNO,
                    destinationGraph = graphFor(perfil)
                )
            }
        )

        professorNavGraph(
            usuarioLogadoFlow = sessionViewModel.usuarioLogado,
            darkTheme = darkTheme,
            onDarkThemeChange = onDarkThemeChange,
            onLogout = {
                sessionViewModel.limparUsuarioLogado()
                replaceGraph(
                    currentGraph = GraphRoutes.PROFESSOR,
                    destinationGraph = GraphRoutes.AUTH
                )
            },
            onSessaoAusente = {
                replaceGraph(
                    currentGraph = GraphRoutes.PROFESSOR,
                    destinationGraph = GraphRoutes.AUTH
                )
            },
            onPerfilInvalido = { perfil ->
                replaceGraph(
                    currentGraph = GraphRoutes.PROFESSOR,
                    destinationGraph = graphFor(perfil)
                )
            }
        )
    }
}