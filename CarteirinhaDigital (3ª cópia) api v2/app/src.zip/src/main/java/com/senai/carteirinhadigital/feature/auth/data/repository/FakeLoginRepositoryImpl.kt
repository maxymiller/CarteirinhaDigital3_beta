package com.senai.carteirinhadigital.feature.auth.data.repository

import androidx.compose.ui.geometry.Rect
import com.senai.carteirinhadigital.feature.auth.domain.model.PerfilAcesso
import com.senai.carteirinhadigital.feature.auth.domain.model.UsuarioLogado
import com.senai.carteirinhadigital.feature.auth.domain.repository.LoginRepository
import kotlinx.coroutines.delay

class FakeLoginRepositoryImpl : LoginRepository {
    override suspend fun login(
        usuario: String,
        senha: String
    ): Result<UsuarioLogado> {
        /*TODO("Not yet implemented")*/
        delay(1500)
        return if (usuario.equals("maxy") && senha.equals("1234")) {
            Result.success(
                UsuarioLogado(
                    id = "1",
                    nome = "maxymiller",
                    matricula = "2026000001",
                    perfil = PerfilAcesso.ALUNO,
                    curso = "Desenvolvimento de Sistemas",
                    turma = "2DEVEST-A",
                    token = "aHR0cHM6Ly95b3V0dS5iZS9WeXhYQjJIcEhIbz9zaT05bzA4eGJrNmRLYnB5WEc1" // base64 atob("")
                )
            )

        } else if (usuario.equals("maxy2") && senha.equals("1234")) {
            Result.success(
                UsuarioLogado(
                    id = "2",
                    nome = "maxymiller2",
                    matricula = "2026000001",
                    perfil = PerfilAcesso.ALUNO,
                    curso = "Desenvolvimento de Sistemas",
                    turma = "2DEVEST-A",
                    token = "aHR0cHM6Ly95b3V0dS5iZS9WeXhYQjJIcEhIbz9zaT05bzA4eGJrNmRLYnB5WEc1" // base64 atob("")
                )
            )
        } else {
            Result.failure(
                IllegalArgumentException("Login ou senha inválidos.")
            )
        }
    }
}