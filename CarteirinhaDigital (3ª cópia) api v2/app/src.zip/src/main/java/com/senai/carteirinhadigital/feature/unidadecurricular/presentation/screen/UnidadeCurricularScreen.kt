package com.senai.carteirinhadigital.feature.unidadecurricular.presentation.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.senai.carteirinhadigital.R
import com.senai.carteirinhadigital.feature.aluno.unidadescurriculares.presentation.UnidadeCurricularViewModel
import com.senai.carteirinhadigital.feature.unidadecurricular.data.dataSource

@Composable
fun UnidadeCurricularScreen(
    modifier: Modifier = Modifier,
    viewModel: UnidadeCurricularViewModel
) {
    //val unidadeCurriculares = dataSource()

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val errorMessage = uiState.errorMessage

    Image(
        painter = painterResource(id = R.drawable.tardis_do_maxy),
        contentDescription = "tardis",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        //verticalArrangement = Arrangement.SpaceAround
        verticalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.senai_sao_paulo_logo),
            contentDescription = "senai são paulo logo"
        )
        LaunchedEffect(Unit) {
            viewModel.carregar()
        }
        when {
            uiState.isLoading -> {
                Box(
                    modifier = modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            errorMessage != null -> {
                Column(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .background(
                            color = MaterialTheme.colorScheme.onPrimary
                        ),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error
                    )
                    Button(
                        modifier = Modifier
                            .padding(top = 16.dp),
                        onClick = {
                            viewModel.carregar()
                        }
                    ) {
                        Text("Tentar novamente")
                    }
                }
            }

            uiState.unidades.isEmpty() -> {
                Box(
                    modifier = modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhuma unidade curricular encontrada.")
                }
            }

            else -> {
                /*LazyColumn(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 12.dp
                        ),
                    verticalArrangement = Arrangement
                        .spacedBy(12.dp)
                ) {
                    items(
                        items = uiState.unidades,
                        key = { it.id }
                    ) { unidadeCurricular ->
                        UnidadeCurricularCard(
                            unidadeCurricular = unidadeCurricular
                        )
                    }
                }*/
                val unidadeCurriculares = uiState.unidades
                UnidadeCurricularContent(
                    unidadeCurriculares = unidadeCurriculares
                )
            }
        }
    }
}