package com.senai.carteirinhadigital.feature.homeProfessor.presentation

//import android.graphics.Color
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.senai.carteirinhadigital.R
import com.senai.carteirinhadigital.app.navigation.Routes


//
@Composable
fun HomeProfessorScreen(
    modifier: Modifier = Modifier,
    //onLoginClick: () -> Unit = {}
    navController: NavController
    //navController: () -> NavController = {}
) {

    Image(
        painter = painterResource(id = R.drawable.tardis_do_maxy),
        contentDescription = "tardis",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        //verticalArrangement = Arrangement.SpaceAround
        verticalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.senai_sao_paulo_logo),
            contentDescription = "senai são paulo logo"
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            //verticalArrangement = Arrangement.SpaceAround
            verticalArrangement = Arrangement.Center,
            modifier = modifier.fillMaxSize()
        ) {
            Column(
                modifier = modifier
                    .background(
                        //width = 4.dp,
                        color = Color.Black,
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
            Text(
                text = "Turmas",
                color = MaterialTheme.colorScheme.primary
            )
            Button(
                //onClick = onLoginClick,
                onClick = {
                    navController.navigate(Routes.Desenvolvimento_de_sistemas)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Desenvolvimento de sistemas")
            }
//            Button(
//                //onClick = onLoginClick,
//                onClick = {
//                    navController.navigate(Routes.Login)
//                },
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MaterialTheme.colorScheme.primary,
//                    contentColor = MaterialTheme.colorScheme.onPrimary
//                ),
//                modifier = Modifier
//                    .width(200.dp),
//                shape = RoundedCornerShape(5.dp),
//                border = BorderStroke(
//                    width = 4.dp,
//                    color = MaterialTheme.colorScheme.onPrimary
//                )
//            ) {
//                Text("Login")
//            }
            Button(
                //onClick = onLoginClick,
                onClick = {
                    navController.navigate(Routes.Mecatronica)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Mecatrônica")
            }
            Button(
                onClick = {
                    navController.navigate(Routes.Eletronica)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Eletrônica")
            }
            Text(
                text = "Unidades",
                color = MaterialTheme.colorScheme.primary
            )
            Button(
                onClick = {
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Eletrônica Digital")
            }
            Button(
                onClick = {
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Semicondutores")
            }
            Button(
                onClick = {
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Diodos")
            }
            Text(
                text = "Mais",
                color = MaterialTheme.colorScheme.primary
            )
            Button(
                onClick = {
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Notas/Faltas/Presenças")
            }
            Button(
                onClick = {
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Ano/Série/Manhã/Tarde")
            }
            }
        }
    }
}

/*@Preview(
    showSystemUi = true,
    showBackground = true
)
@Composable
fun LoginScreenAppPreviewDark() {
    CarteirinhaDigitalTheme {
        LoginScreen(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize()
        )
    }
}*/
//@Preview(
//    showSystemUi = true,
//    showBackground = true
//)
//@Composable
//fun HomeScreenAppPreviewDark() {
//    //HomeDigitalTheme {
//        HomeScreen(
//            modifier = Modifier
//                .padding(16.dp)
//                .fillMaxSize()
//        )
//    //}
//}