package com.senai.carteirinhadigital.feature.unidadecurricular.presentation.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.senai.carteirinhadigital.R
import com.senai.carteirinhadigital.feature.unidadecurricular.data.dataSource

@Composable
fun UnidadeCurricularScreen(
    modifier: Modifier = Modifier
) {
    val unidadeCurriculares = dataSource()

    Image(
        painter = painterResource(id = R.drawable.tardis_do_maxy),
        contentDescription = "tardis",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        //verticalArrangement = Arrangement.SpaceAround
        verticalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.senai_sao_paulo_logo),
            contentDescription = "senai são paulo logo"
        )
        UnidadeCurricularContent(
            unidadeCurriculares = unidadeCurriculares
        )
    }
}