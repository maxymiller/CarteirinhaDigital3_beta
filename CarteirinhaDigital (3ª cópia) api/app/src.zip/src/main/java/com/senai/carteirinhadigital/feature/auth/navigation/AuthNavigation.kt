package com.senai.carteirinhadigital.feature.auth.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.app.session.SessionViewModel
import com.senai.carteirinhadigital.feature.auth.domain.model.UsuarioLogado
import com.senai.carteirinhadigital.feature.auth.presentation.LoginScreen

//import com.rafaelcosta.

fun NavGraphBuilder.authScreen(
    //onNavigateToCarteirinha: () -> Unit
    navController: NavController,
    onLoginSucesso: (UsuarioLogado) -> Unit
) {
    composable(Routes.Login) {
        LoginScreen(
            onLoginSucesso = onLoginSucesso
            //onLoginClick = onNavigateToCarteirinha
            //navController = navController
        )
    }
}