package com.senai.carteirinhadigital.feature.auth.data.remote.service

import com.senai.carteirinhadigital.feature.auth.data.remote.dto.LoginRequestDTO
import com.senai.carteirinhadigital.feature.auth.data.remote.dto.LoginResponseDTO
import retrofit2.http.Body
import retrofit2.http.POST

interface AuthApi {
    @POST("auth/login")
    suspend fun login(@Body body: LoginRequestDTO): LoginResponseDTO
}