package com.senai.carteirinhadigital.feature.carteirinha.presentation

//import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.rafaelcosta.carteirinhadigital_4devm_t1.feature.carteirinha.presentation.component.QrCode
import com.senai.carteirinhadigital.core.designsystem.theme.CarteirinhaDigitalTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import com.senai.carteirinhadigital.R
import com.senai.carteirinhadigital.app.App

//class MainActivity : ComponentActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContent {
//            /*CarteirinhaDigitalTheme {
//                Scaffold { innerPadding ->
//                    CarteirinhaScreen(
//                        modifier = Modifier
//                            .padding(innerPadding)
//                            .fillMaxSize()
//                    )
//                }
//            }*/
//            //App()
//            mainmaxymiller()
//        }
//    }
//}
//
@Composable
fun CarteirinhaScreen(
    modifier: Modifier = Modifier,
    onBackClick: () -> Unit = {}
) {
    Image(
        painter = painterResource(id = R.drawable.tardis_do_maxy),
        contentDescription = "tardis",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        //verticalArrangement = Arrangement.SpaceAround
        verticalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.senai_sao_paulo_logo),
            contentDescription = "senai são paulo logo"
        )
        Image(
            painter = painterResource(R.drawable.maxyblack14static),
            contentDescription = "maxymiller static",
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .border(
                    width = 4.dp,
                    color = Color.Blue,
                    CircleShape
                )
        )
        Column(
            modifier = Modifier
                .background(
                    //width = 4.dp,
                    color = Color.Black,
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Nome:",
                color = Color.White
            )
            Text(
                text = "Maxymiller",
                color = Color.White
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Curso:",
                color = Color.White
            )
            Text(
                text = "Desenvolvimento Sistemas",
                color = Color.White
            )
        }
            }
        QrCode(
            "teste",
            modifier = Modifier
                .size(200.dp)
                .border(
                    width = 4.dp,
                    color = Color.Blue,
                )

        )
    }
}

@Preview(
    showSystemUi = true,
    showBackground = true
)
@Composable
fun CarteirinhaScreenAppPreview() {
    CarteirinhaDigitalTheme {
        CarteirinhaScreen(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize()
        )
    }
}