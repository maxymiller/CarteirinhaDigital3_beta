package com.senai.carteirinhadigital.feature.homeProfessor.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.feature.homeProfessor.presentation.HomeProfessorScreen

fun NavGraphBuilder.homeProfessorScreen(
    //onNavigateToHome: () -> Unit,
    navController: NavController
) {
    composable(Routes.homeProfessor) {
        HomeProfessorScreen(
            //onBackClick = onNavigateToHome,
            navController = navController
        )
    }
}