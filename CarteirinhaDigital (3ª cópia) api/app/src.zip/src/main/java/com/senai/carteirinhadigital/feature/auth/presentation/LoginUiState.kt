package com.senai.carteirinhadigital.feature.auth.presentation

import com.senai.carteirinhadigital.feature.auth.domain.model.UsuarioLogado

data class LoginUiState(
    val usuario: String = "",
    val senha: String = "",
    val inLoading: Boolean = false,
    val errorMessage: String? = null,
    val usuarioLogado: UsuarioLogado? = null
){
    val loginRealizado: Boolean
        get() = usuarioLogado != null
}