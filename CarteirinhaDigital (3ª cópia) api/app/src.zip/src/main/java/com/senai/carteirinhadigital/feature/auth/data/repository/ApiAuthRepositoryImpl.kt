package com.senai.carteirinhadigital.feature.auth.data.repository

import com.senai.carteirinhadigital.feature.auth.data.remote.dto.ErrorResponseDTO
import com.senai.carteirinhadigital.feature.auth.data.remote.dto.LoginRequestDTO
import com.senai.carteirinhadigital.feature.auth.data.remote.service.AuthApi
import com.senai.carteirinhadigital.feature.auth.domain.model.UsuarioLogado
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.io.IOException

class ApiLoginRepositoryImpl(
    private val api: AuthApi
) : LoginRepository {

    override suspend fun login(usuario: String, senha: String): Result<UsuarioLogado> {
        return runCatching {
            val response = api.login(LoginRequestDTO(usuario = usuario, senha = senha))
            UsuarioLogado(
                id = response.id,
                nome = response.nome,
                curso = response.curso,
                turma = response.turma,
                token = response.token
            )
        }.recoverCatching { throwable ->
            throw mapToDomainError(throwable)
        }
    }

    private fun mapToDomainError(throwable: Throwable): Throwable {
        return when (throwable) {
            is HttpException -> mapHttpException(throwable)
            is IOException -> IllegalStateException(
                "Não foi possível conectar à API local. Verifique se ela está rodando."
            )
            else -> IllegalStateException(throwable.message ?: "Erro ao fazer login.")
        }
    }

    private fun mapHttpException(exception: HttpException): Throwable {
        if (exception.code() == 401) {
            return IllegalArgumentException("Login ou senha inválidos")
        }

        val messageFromBody = exception.response()?.errorBody()?.string()?.let { body ->
            runCatching {
                Json { ignoreUnknownKeys = true }.decodeFromString<ErrorResponseDTO>(body).message
            }.getOrNull()
        }

        return IllegalStateException(messageFromBody ?: "Erro no servidor (${exception.code()}).")
    }
}