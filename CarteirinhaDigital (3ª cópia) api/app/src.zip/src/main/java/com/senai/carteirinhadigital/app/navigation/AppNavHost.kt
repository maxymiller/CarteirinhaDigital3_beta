package com.senai.carteirinhadigital.app.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.senai.carteirinhadigital.app.session.SessionViewModel
import com.senai.carteirinhadigital.feature.auth.navigation.authScreen
import com.senai.carteirinhadigital.feature.carteirinha.navigation.carteirinhaScreen
import com.senai.carteirinhadigital.feature.desenvolvimentoDeSistemas.navigation.desenvolvimentoDeSistemasScreen
import com.senai.carteirinhadigital.feature.eletronica.navigation.eletronicaScreen
import com.senai.carteirinhadigital.feature.home.navigation.homeScreen
import com.senai.carteirinhadigital.feature.homeProfessor.navigation.homeProfessorScreen
import com.senai.carteirinhadigital.feature.mecatronica.navigation.mecatronicaScreen
import com.senai.carteirinhadigital.feature.unidadecurricular.navigation.unidadeScreen

@Composable
fun AppNavHost() {
    val navController = rememberNavController()

    val sessionViewModel: SessionViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Routes.Login
    ) {
        authScreen(
            //onNavigateToCarteirinha = {
                //navController.navigate(Routes.Carteirinha)
            //}
            navController = navController,
            onLoginSucesso = {
                    usuario ->
                    sessionViewModel.setUsuarioLogado(usuario)
                    if (usuario.id == "1") {
                        navController.navigate(Routes.Home)
                    } else if (usuario.id == "2") {
                        navController.navigate(Routes.homeProfessor)
                    }
            }
        )

        carteirinhaScreen(
            onNavigateToLogin = {
                navController.navigate(Routes.Login)
            }
        )

        homeScreen(
            //onNavigateToHome = {
                //navController.navigate(Routes.Home)
            //}
            navController = navController
        )

        unidadeScreen(
            navController = navController
        )

        homeProfessorScreen(
            navController = navController
        )

        desenvolvimentoDeSistemasScreen(
            navController = navController
        )

        mecatronicaScreen(
            navController = navController
        )

        eletronicaScreen(
            navController = navController
        )
    }
}