package com.senai.carteirinhadigital.feature.unidadecurricular.presentation.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.senai.carteirinhadigital.feature.unidadecurricular.domain.model.UnidadeCurricular
import com.senai.carteirinhadigital.feature.unidadecurricular.presentation.component.UnidadeCurricularCard

//import java.lang.reflect.Modifier

@Composable
fun UnidadeCurricularContent(
    modifier: Modifier = Modifier,
    unidadeCurriculares: List<UnidadeCurricular>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(
            unidadeCurriculares
        ) {
            unidadeCurricular ->
            UnidadeCurricularCard(unidadeCurricular = unidadeCurricular)
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true
)
@Composable
fun UnidadeCurricularContentPreview() {
    UnidadeCurricularContent(
        unidadeCurriculares = listOf(
            UnidadeCurricular(id = "1", nome = "Matemálica", professor = "Dr. Silva", nota1 = 8.5, nota2 = 7.0, media = 7.75, faltas = 2),
            UnidadeCurricular(id = "2", nome = "Portugues", professor = "Dr. Silva", nota1 = 8.5, nota2 = 7.0, media = 7.75, faltas = 2),
            UnidadeCurricular(id = "3", nome = "Banco de Dados", professor = "Dr. Silva", nota1 = 8.5, nota2 = 7.0, media = 7.75, faltas = 2)
        )
    )
}
