package com.senai.carteirinhadigital.feature.auth.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.senai.carteirinhadigital.feature.auth.data.repository.FakeLoginRepositoryImpl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.senai.carteirinhadigital.feature.auth.data.repository.LoginRepository
import com.senai.carteirinhadigital.feature.auth.data.repository.LoginRepositoryProvider

class LoginViewMode (
    private val repository: LoginRepository = LoginRepositoryProvider.provide(),

    //private fun fazerLogin() {
    //    if (state.usu)
    //}
): ViewModel(){

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun OnEvent(event: LoginEvent){
        when(event){
            is LoginEvent.OnUsuarioChange -> {
                _uiState.update { state ->
                    state.copy(
                        usuario = event.value,
                        errorMessage = null
                    )
                }
            }
            is LoginEvent.OnSenhaChange -> {
                _uiState.update { state ->
                    state.copy(
                        senha = event.value,
                        errorMessage = null
                    )
                }
            }
            LoginEvent.OnEntrarClick -> fazerLogin()

            LoginEvent.OnNavegacaoRealizada -> {
                _uiState.update {
                    it.copy(
                        usuarioLogado = null
                    )
                }
            }

            //fun OnEvent(event: LoginEvent){

            //}

            //private fun

            //LoginEvent.OnEntrarClick -> repository
        }
    }

    private fun fazerLogin() {
        val state = _uiState.value

        if (state.usuario.isBlank() || state.senha.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Preencha login e senha"
                )
            }
            return
        }
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    inLoading = true,
                    errorMessage = null,
                    usuarioLogado = null
                )
            }
            val result = repository.login(
                usuario = state.usuario.trim(),
                senha = state.senha.trim()
            )
            result
                .onSuccess { usuarioLogado ->
                _uiState.update {
                    it.copy(
                        inLoading = false,
                        errorMessage = null,
                        usuarioLogado = usuarioLogado
                    )
                }
            }
                .onFailure { throwable ->
                    _uiState.update {
                        it.copy(
                            inLoading = false,
                            errorMessage = throwable.message?:"Erro ao Fazer Login"
                        )
                    }

                }
        }
    }
}