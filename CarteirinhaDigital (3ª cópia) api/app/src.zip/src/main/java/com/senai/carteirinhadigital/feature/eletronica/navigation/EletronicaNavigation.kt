package com.senai.carteirinhadigital.feature.eletronica.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.feature.eletronica.presentation.EletronicaScreen

fun NavGraphBuilder.eletronicaScreen(
    //onNavigateToHome: () -> Unit,
    navController: NavController
) {
    composable(Routes.Eletronica) {
        EletronicaScreen(
            //onBackClick = onNavigateToHome,
            navController = navController
        )
    }
}