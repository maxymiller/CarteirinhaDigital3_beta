package com.senai.carteirinhadigital.app.navigation

object Routes {
    const val Login = "login"
    const val Carteirinha = "carteirinha"
    const val Home = "home"
    const val Unidade = "unidade"
    const val homeProfessor = "homeProfessor"
    const val Desenvolvimento_de_sistemas = "desenvolvimentoDeSistemas"
    const val Mecatronica = "mecatronica"
    const val Eletronica = "eletronica"
}