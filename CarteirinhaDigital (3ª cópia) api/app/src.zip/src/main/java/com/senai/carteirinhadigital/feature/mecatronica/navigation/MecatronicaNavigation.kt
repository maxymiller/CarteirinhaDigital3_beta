package com.senai.carteirinhadigital.feature.mecatronica.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.feature.mecatronica.presentation.MecatronicaScreen

fun NavGraphBuilder.mecatronicaScreen(
    //onNavigateToHome: () -> Unit,
    navController: NavController
) {
    composable(Routes.Mecatronica) {
        MecatronicaScreen(
            //onBackClick = onNavigateToHome,
            navController = navController
        )
    }
}