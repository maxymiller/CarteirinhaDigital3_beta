package com.senai.carteirinhadigital.feature.auth.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class LoginRequestDTO(
    val usuario: String,
    val senha: String
)