package com.senai.carteirinhadigital.feature.auth.presentation

sealed interface LoginEvent {
    data class OnUsuarioChange(var value: String): LoginEvent
    data class OnSenhaChange(var value: String): LoginEvent
    data object OnEntrarClick: LoginEvent
    data object OnNavegacaoRealizada: LoginEvent
}