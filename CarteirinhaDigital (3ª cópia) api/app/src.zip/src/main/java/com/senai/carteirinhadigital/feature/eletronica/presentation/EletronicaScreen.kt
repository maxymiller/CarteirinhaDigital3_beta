package com.senai.carteirinhadigital.feature.eletronica.presentation

//import android.graphics.Color
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.senai.carteirinhadigital.R


//
@Composable
fun EletronicaScreen(
    modifier: Modifier = Modifier,
    //onLoginClick: () -> Unit = {}
    navController: NavController
    //navController: () -> NavController = {}
) {

    Image(
        painter = painterResource(id = R.drawable.tardis_do_maxy),
        contentDescription = "tardis",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        //verticalArrangement = Arrangement.SpaceAround
        verticalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.senai_sao_paulo_logo),
            contentDescription = "senai são paulo logo"
        )
        Column(
            modifier = modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            //verticalArrangement = Arrangement.SpaceAround
            verticalArrangement = Arrangement.Center
        ) {
            Column(
                modifier = modifier
                    .background(
                        //width = 4.dp,
                        color = Color.Black,
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
            Text(
                text = "Eletrônica",
                color = MaterialTheme.colorScheme.primary
                //color = Color.White
            )
            Button(
                //onClick = onLoginClick,
                onClick = {
                    //navController.navigate(Routes.Carteirinha)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Eletrônica Digital")
            }
//            Button(
//                //onClick = onLoginClick,
//                onClick = {
//                    navController.navigate(Routes.Login)
//                },
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MaterialTheme.colorScheme.primary,
//                    contentColor = MaterialTheme.colorScheme.onPrimary
//                ),
//                modifier = Modifier
//                    .width(200.dp),
//                shape = RoundedCornerShape(5.dp),
//                border = BorderStroke(
//                    width = 4.dp,
//                    color = MaterialTheme.colorScheme.onPrimary
//                )
//            ) {
//                Text("Login")
//            }
            Button(
                //onClick = onLoginClick,
                onClick = {
                    //navController.navigate(Routes.Unidade)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .width(200.dp),
                shape = RoundedCornerShape(5.dp),
                border = BorderStroke(
                    width = 4.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Semicondutores")
            }
                Button(
                    //onClick = onLoginClick,
                    onClick = {
                        //navController.navigate(Routes.Unidade)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .width(200.dp),
                    shape = RoundedCornerShape(5.dp),
                    border = BorderStroke(
                        width = 4.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Diodos")
                }
            }
        }
    }
}

/*@Preview(
    showSystemUi = true,
    showBackground = true
)
@Composable
fun LoginScreenAppPreviewDark() {
    CarteirinhaDigitalTheme {
        LoginScreen(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize()
        )
    }
}*/
//@Preview(
//    showSystemUi = true,
//    showBackground = true
//)
//@Composable
//fun HomeScreenAppPreviewDark() {
//    //HomeDigitalTheme {
//        HomeScreen(
//            modifier = Modifier
//                .padding(16.dp)
//                .fillMaxSize()
//        )
//    //}
//}