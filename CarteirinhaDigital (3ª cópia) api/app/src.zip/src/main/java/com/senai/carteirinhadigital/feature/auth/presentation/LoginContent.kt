package com.senai.carteirinhadigital.feature.auth.presentation

import android.transition.CircularPropagation
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.senai.carteirinhadigital.R

@Composable
fun LoginContent (
    modifier: Modifier = Modifier,
    uiState: LoginUiState,
    onEvent:(LoginEvent)-> Unit
){
    var login by remember { mutableStateOf(value = "") }
    var senha by remember { mutableStateOf(value = "") }

    var loginError by remember { mutableStateOf(false) }
    var senhaError by remember { mutableStateOf(false) }

    var onClick by remember { mutableStateOf(false) }
    var onButton by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf(value = "") }

    Image(
    painter = painterResource(id = R.drawable.tardis_do_maxy),
    contentDescription = "tardis",
    contentScale = ContentScale.Crop,
    modifier = Modifier.fillMaxSize()
    )
    Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    //verticalArrangement = Arrangement.SpaceAround
    verticalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.senai_sao_paulo_logo),
            contentDescription = "senai são paulo logo"
        )
        Column(
            modifier = modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            //verticalArrangement = Arrangement.SpaceAround,
            verticalArrangement = Arrangement.Center
        ) {
            Column(
                modifier = Modifier
                    .background(
                        //width = 4.dp,
                        color = Color.Black,

                    )
                    .fillMaxWidth(.8f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
            ) {
                Text(
                    text = "Login",
                    color = MaterialTheme.colorScheme.primary
                )
                TextField(
                    value = uiState.usuario,
                    onValueChange = { value ->
                        onEvent(
                            LoginEvent.OnUsuarioChange(value)
                        )
                        login = value
                        loginError = false
                        onButton = false
                    },
                    label = {
                        if (loginError && login == "") {
                            Text("email (o email não pode ficar em branco)")
                        } else if (loginError) {
                            Text("email (email ou senha está errado)")
                        } else {
                            Text("email")
                        }
                    },
                    isError = loginError
                )
                TextField(
                    value = uiState.senha,
                    onValueChange = { value ->
                        onEvent(
                            LoginEvent.OnSenhaChange(value)
                        )
                        senha = value
                        senhaError = false
                        onButton = false
                    },
                    label = {
                        if (senhaError && senha == "") {
                            Text("senha (a senha não pode ficar em branco)")
                        } else if (senhaError) {
                            Text("senha (email ou senha está errado)")
                        } else {
                            Text("senha")
                        }
                    },
                    isError = senhaError
                )
                Button(
                    //onClick = onLoginClick,
                    onClick = {
                        onEvent(LoginEvent.OnEntrarClick)
                        onClick = true
                    },
                    enabled = !uiState.inLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .width(200.dp),
                    shape = RoundedCornerShape(5.dp),
                    border = BorderStroke(
                        width = 4.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    onButton = false
                    if (uiState.inLoading){
                        loginError = false
                        senhaError = false
                        CircularProgressIndicator(
                            modifier = Modifier.fillMaxWidth(0.12f),
                            strokeWidth = 2.dp
                        )
                    }else {
                        Text("Entrar")
                        if (onClick && !onButton) {
                            onButton = true
                        }
                        onClick = false
                        if (uiState.errorMessage != null) {
                            errorMessage = uiState.errorMessage
                        }else{
                            errorMessage = ""
                        }
                    }
                    if (login == "" && onButton) {
                        loginError = true
                    } else if(uiState.errorMessage != null) {
                        loginError = true
                    }
                    if (senha == "" && onButton) {
                        senhaError = true
                    } else if(uiState.errorMessage != null) {
                        senhaError = true
                    }
                }
                Text(
                    text = errorMessage,
                    color = Color.Red
                )
            }
        }
    }
}

//@Preview(
//    showSystemUi = true,
//    showBackground = true
//)
//@Composable
//fun LoginScreenAppPreviewDark(
//    //modifier: Modifier = Modifier
//) {
//    //CarteirinhaDigitalTheme {
//        LoginContent(
//            modifier: Modifier = Modifier,
//            uiState: LoginUiState,
//            /*modifier = Modifier
//                .padding(16.dp)
//                .fillMaxSize()*/
//        )
//    //}
//}