package com.senai.carteirinhadigital.feature.home.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.feature.home.presentation.HomeScreen

fun NavGraphBuilder.homeScreen(
    //onNavigateToHome: () -> Unit,
    navController: NavController
) {
    composable(Routes.Home) {
        HomeScreen(
            //onBackClick = onNavigateToHome,
            navController = navController
        )
    }
}