package com.senai.carteirinhadigital.feature.auth.data.remote.service

import com.senai.carteirinhadigital.feature.unidadecurricular.data.remote.dto.UnidadeCurricularDTO
import retrofit2.http.GET
import retrofit2.http.Header
import java.sql.SQLInvalidAuthorizationSpecException

interface UnidadeCurricularApi {
    @GET("unidades-curriculares")
    suspend fun listar(
        @Header("Authorization")
        authorization:String
    ): List<UnidadeCurricularDTO>
}