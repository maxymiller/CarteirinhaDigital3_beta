package com.senai.carteirinhadigital.feature.unidadecurricular.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.feature.home.presentation.HomeScreen
import com.senai.carteirinhadigital.feature.unidadecurricular.domain.model.UnidadeCurricular
import com.senai.carteirinhadigital.feature.unidadecurricular.presentation.UnidadeScreen
import com.senai.carteirinhadigital.feature.unidadecurricular.presentation.screen.UnidadeCurricularContent
import com.senai.carteirinhadigital.feature.unidadecurricular.presentation.screen.UnidadeCurricularScreen

fun NavGraphBuilder.unidadeScreen(
    //onNavigateToHome: () -> Unit,
    navController: NavController
) {
    composable(Routes.Unidade) {
        UnidadeCurricularScreen(
            //
        )
    }
}