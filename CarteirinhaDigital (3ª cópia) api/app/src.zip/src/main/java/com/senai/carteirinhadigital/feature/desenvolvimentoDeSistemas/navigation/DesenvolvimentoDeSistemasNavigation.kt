package com.senai.carteirinhadigital.feature.desenvolvimentoDeSistemas.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.feature.desenvolvimentoDeSistemas.presentation.DesenvolvimentoDeSistemasScreen

fun NavGraphBuilder.desenvolvimentoDeSistemasScreen(
    //onNavigateToHome: () -> Unit,
    navController: NavController
) {
    composable(Routes.Desenvolvimento_de_sistemas) {
        DesenvolvimentoDeSistemasScreen(
            //onBackClick = onNavigateToHome,
            navController = navController
        )
    }
}