package com.senai.carteirinhadigital.feature.auth.presentation

//import android.graphics.Color
import android.transition.CircularPropagation
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.senai.carteirinhadigital.R
import com.senai.carteirinhadigital.app.navigation.Routes
import com.senai.carteirinhadigital.core.designsystem.theme.CarteirinhaDigitalTheme
import com.senai.carteirinhadigital.feature.auth.domain.model.UsuarioLogado


//
@Composable
fun LoginScreen(
    modifier: Modifier = Modifier,
    onLoginSucesso: (UsuarioLogado) -> Unit,
    viewMode: LoginViewMode = viewModel()

    //onLoginClick: () -> Unit = {}
//    navController: NavController = NavController(
//        LocalContext.current
//    )
) {
    //var login by remember { mutableStateOf(value = "") }
    //var senha by remember { mutableStateOf(value = "") }

    //var loginError by remember { mutableStateOf(false) }
    //var senhaError by remember { mutableStateOf(false) }

    val uiState by viewMode.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(uiState.usuarioLogado) {
        uiState.usuarioLogado?.let{ ususrio ->
            viewMode.OnEvent(LoginEvent.OnNavegacaoRealizada)
            onLoginSucesso(ususrio)
        }
    }

    LoginContent(
        uiState = uiState,
        onEvent = viewMode::OnEvent,
        modifier = modifier.fillMaxSize()
    )
}

//@Preview(
//    showSystemUi = true,
//    showBackground = true
//)
//@Composable
//fun LoginScreenAppPreviewDark(
//    //modifier: Modifier = Modifier
//) {
//    CarteirinhaDigitalTheme {
//        LoginScreen(
//            /*modifier = Modifier
//                .padding(16.dp)
//                .fillMaxSize()*/
//        )
//    }
//}