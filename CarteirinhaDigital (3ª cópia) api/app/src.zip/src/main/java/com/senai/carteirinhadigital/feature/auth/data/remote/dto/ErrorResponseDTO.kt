package com.senai.carteirinhadigital.feature.auth.data.remote.dto
import kotlinx.serialization.Serializable

@Serializable
data class ErrorResponseDTO(
    val message: String? = null
)